let color = "#z3aa757";

chrome.runtime.onInstalled.addListener(() => {
     //add an action here
});